"use client"

import { useState, useEffect, useCallback } from "react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Header } from "@/components/dashboard/header"
import { StatsCards } from "@/components/dashboard/stats-cards"
import { ShipmentsList, type Shipment } from "@/components/dashboard/shipments-list"
import { WorldMap } from "@/components/dashboard/world-map"
import { ShipmentModal } from "@/components/dashboard/shipment-modal"
import { NotificationsPanel } from "@/components/dashboard/notifications-panel"
import { CommandPalette } from "@/components/dashboard/command-palette"
import { ActivityFeed } from "@/components/dashboard/activity-feed"
import { QuickActions } from "@/components/dashboard/quick-actions"
import { ToastNotification, type Toast } from "@/components/dashboard/toast-notification"
import { NewShipmentModal } from "@/components/dashboard/new-shipment-modal"
import { KeyboardShortcuts } from "@/components/dashboard/keyboard-shortcuts"
import { FleetView } from "@/components/dashboard/views/fleet-view"
import { TrackingView } from "@/components/dashboard/views/tracking-view"
import { AnalyticsView } from "@/components/dashboard/views/analytics-view"
import { CustomersView } from "@/components/dashboard/views/customers-view"
import { ReportsView } from "@/components/dashboard/views/reports-view"
import { SettingsView } from "@/components/dashboard/views/settings-view"
import { ShipmentsView } from "@/components/dashboard/views/shipments-view"

type StatusFilter = "in-transit" | "delivered" | "pending" | "delayed" | null

export default function DashboardPage() {
  const [activeView, setActiveView] = useState("overview")
  const [showNotifications, setShowNotifications] = useState(false)
  const [showCommandPalette, setShowCommandPalette] = useState(false)
  const [showActivityFeed, setShowActivityFeed] = useState(false)
  const [showKeyboardShortcuts, setShowKeyboardShortcuts] = useState(false)
  const [showNewShipmentModal, setShowNewShipmentModal] = useState(false)
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(null)
  const [statusFilter, setStatusFilter] = useState<StatusFilter>(null)
  const [globalSearch, setGlobalSearch] = useState("")
  const [toasts, setToasts] = useState<Toast[]>([])

  const addToast = useCallback((type: Toast["type"], title: string, description?: string) => {
    const id = Date.now().toString()
    setToasts((prev) => [...prev, { id, type, title, description }])
  }, [])

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id))
  }, [])

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement
      const isInputFocused = ["INPUT", "TEXTAREA"].includes(target.tagName)

      // Command/Ctrl + K for command palette
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault()
        setShowCommandPalette(true)
      }
      // Command/Ctrl + / for keyboard shortcuts
      if ((e.metaKey || e.ctrlKey) && e.key === "/") {
        e.preventDefault()
        setShowKeyboardShortcuts(true)
      }
      // N for new shipment (when no input is focused)
      if (e.key === "n" && !isInputFocused) {
        e.preventDefault()
        setShowNewShipmentModal(true)
      }
      // G + key for navigation (when no input is focused)
      if (e.key === "g" && !isInputFocused) {
        const handleNavKey = (navEvent: KeyboardEvent) => {
          const navMap: Record<string, string> = {
            o: "overview",
            s: "shipments",
            f: "fleet",
            t: "tracking",
            a: "analytics",
            c: "customers",
            r: "reports",
          }
          if (navMap[navEvent.key]) {
            navEvent.preventDefault()
            setActiveView(navMap[navEvent.key])
            addToast("info", "Navigation", `Switched to ${navMap[navEvent.key]}`)
          }
          window.removeEventListener("keydown", handleNavKey)
        }
        window.addEventListener("keydown", handleNavKey, { once: true })
        setTimeout(() => window.removeEventListener("keydown", handleNavKey), 1000)
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [addToast])

  const handleLogout = () => {
    addToast("info", "Logging out...", "You will be redirected shortly")
  }

  const handleViewChange = (view: string) => {
    setActiveView(view)
    setStatusFilter(null)
    setGlobalSearch("")
  }

  const handleFilterClick = (filter: StatusFilter) => {
    setStatusFilter(filter)
  }

  const handleSearch = (query: string) => {
    setGlobalSearch(query)
  }

  const handleQuickAction = (action: string) => {
    switch (action) {
      case "new-shipment":
        setShowNewShipmentModal(true)
        break
      case "track-package":
        setActiveView("tracking")
        addToast("info", "Tracking View", "Search for packages to track")
        break
      case "add-vehicle":
        setActiveView("fleet")
        addToast("info", "Fleet Management", "Add new vehicles to your fleet")
        break
      case "generate-report":
        setActiveView("reports")
        addToast("info", "Reports", "Generate custom reports")
        break
      default:
        if (action.startsWith("view-")) {
          setActiveView("shipments")
          addToast("info", "Opening Shipment", `Viewing ${action.replace("view-", "").toUpperCase()}`)
        }
    }
  }

  const handleCommandNavigate = (view: string) => {
    setActiveView(view)
    addToast("info", "Navigation", `Switched to ${view}`)
  }

  const handleNewShipmentSubmit = (data: {
    origin: string
    destination: string
    carrier: string
    weight: string
    customerName: string
  }) => {
    setShowNewShipmentModal(false)
    addToast("success", "Shipment Created", `${data.origin} → ${data.destination} for ${data.customerName}`)
  }

  const renderContent = () => {
    switch (activeView) {
      case "shipments":
        return <ShipmentsView />
      case "fleet":
        return <FleetView />
      case "tracking":
        return <TrackingView />
      case "analytics":
        return <AnalyticsView />
      case "customers":
        return <CustomersView />
      case "reports":
        return <ReportsView />
      case "settings":
        return <SettingsView />
      case "overview":
      default:
        return (
          <div className="space-y-6 max-w-[1800px] mx-auto">
            <StatsCards onFilterClick={handleFilterClick} activeFilter={statusFilter} />
            <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
              <div className="xl:col-span-3 min-h-[400px]">
                <WorldMap />
              </div>
              <div className="xl:col-span-2 min-h-[400px] max-h-[600px]">
                <ShipmentsList onShipmentClick={setSelectedShipment} filterStatus={statusFilter} />
              </div>
            </div>
          </div>
        )
    }
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar
        activeView={activeView}
        onViewChange={handleViewChange}
        onNotificationsClick={() => setShowNotifications(true)}
        onLogout={handleLogout}
      />

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header
          onNotificationsClick={() => setShowNotifications(true)}
          onSearch={handleSearch}
          onCommandPalette={() => setShowCommandPalette(true)}
          onActivityFeed={() => setShowActivityFeed(true)}
          onKeyboardShortcuts={() => setShowKeyboardShortcuts(true)}
        />

        <main className="flex-1 overflow-auto p-6">{renderContent()}</main>
      </div>

      {/* Modals and Panels */}
      <ShipmentModal shipment={selectedShipment} onClose={() => setSelectedShipment(null)} />

      <NotificationsPanel
        open={showNotifications}
        onClose={() => setShowNotifications(false)}
        onMarkAllRead={() => addToast("success", "Notifications", "All notifications marked as read")}
      />

      <CommandPalette
        isOpen={showCommandPalette}
        onClose={() => setShowCommandPalette(false)}
        onNavigate={handleCommandNavigate}
        onAction={handleQuickAction}
      />

      <ActivityFeed isOpen={showActivityFeed} onClose={() => setShowActivityFeed(false)} />

      <KeyboardShortcuts isOpen={showKeyboardShortcuts} onClose={() => setShowKeyboardShortcuts(false)} />

      <NewShipmentModal
        isOpen={showNewShipmentModal}
        onClose={() => setShowNewShipmentModal(false)}
        onSubmit={handleNewShipmentSubmit}
      />

      {/* Quick Actions FAB */}
      <QuickActions onAction={handleQuickAction} />

      {/* Toast Notifications */}
      <ToastNotification toasts={toasts} onRemove={removeToast} />
    </div>
  )
}
