"use client"

import { MapPin, Plane, Ship } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface TrackingPoint {
  id: string
  label: string
  type: "origin" | "destination" | "transit"
  icon: "plane" | "ship"
  x: number
  y: number
}

const trackingPoints: TrackingPoint[] = [
  { id: "1", label: "Shanghai", type: "origin", icon: "ship", x: 78, y: 42 },
  { id: "2", label: "Los Angeles", type: "destination", icon: "ship", x: 15, y: 40 },
  { id: "3", label: "Hamburg", type: "origin", icon: "plane", x: 48, y: 30 },
  { id: "4", label: "New York", type: "destination", icon: "plane", x: 24, y: 38 },
  { id: "5", label: "Tokyo", type: "origin", icon: "ship", x: 85, y: 40 },
  { id: "6", label: "Dubai", type: "transit", icon: "plane", x: 58, y: 45 },
  { id: "7", label: "Singapore", type: "origin", icon: "ship", x: 74, y: 55 },
  { id: "8", label: "Sydney", type: "destination", icon: "ship", x: 88, y: 72 },
]

export function WorldMap() {
  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Global Tracking</CardTitle>
          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-primary" />
              <span className="text-muted-foreground">Origin</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-info" />
              <span className="text-muted-foreground">In Transit</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-success" />
              <span className="text-muted-foreground">Destination</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 p-4 relative">
        <div className="relative w-full h-full min-h-[300px] rounded-lg overflow-hidden bg-secondary/30 border border-border">
          {/* World Map SVG */}
          <svg
            viewBox="0 0 100 60"
            className="absolute inset-0 w-full h-full"
            preserveAspectRatio="xMidYMid slice"
          >
            {/* Simplified World Map Outline */}
            <defs>
              <linearGradient id="mapGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="var(--color-muted)" stopOpacity="0.3" />
                <stop offset="100%" stopColor="var(--color-muted)" stopOpacity="0.1" />
              </linearGradient>
            </defs>
            
            {/* North America */}
            <path
              d="M5,20 Q10,15 20,18 T30,22 Q28,35 25,40 Q20,45 12,42 Q5,38 5,30 Z"
              fill="url(#mapGradient)"
              stroke="var(--color-border)"
              strokeWidth="0.3"
            />
            
            {/* South America */}
            <path
              d="M22,48 Q28,45 30,50 Q32,58 28,65 Q24,68 20,65 Q18,58 20,52 Z"
              fill="url(#mapGradient)"
              stroke="var(--color-border)"
              strokeWidth="0.3"
            />
            
            {/* Europe */}
            <path
              d="M42,22 Q48,18 52,20 Q54,24 52,28 Q48,32 44,30 Q40,28 42,22 Z"
              fill="url(#mapGradient)"
              stroke="var(--color-border)"
              strokeWidth="0.3"
            />
            
            {/* Africa */}
            <path
              d="M44,35 Q52,32 56,38 Q58,48 54,55 Q48,60 42,55 Q38,48 40,42 Q42,38 44,35 Z"
              fill="url(#mapGradient)"
              stroke="var(--color-border)"
              strokeWidth="0.3"
            />
            
            {/* Asia */}
            <path
              d="M55,18 Q65,15 75,18 Q85,22 88,28 Q90,35 85,40 Q78,45 70,42 Q62,38 58,32 Q54,26 55,18 Z"
              fill="url(#mapGradient)"
              stroke="var(--color-border)"
              strokeWidth="0.3"
            />
            
            {/* Australia */}
            <path
              d="M82,55 Q90,52 94,56 Q96,62 92,66 Q86,68 82,64 Q78,60 82,55 Z"
              fill="url(#mapGradient)"
              stroke="var(--color-border)"
              strokeWidth="0.3"
            />

            {/* Shipping Routes */}
            <path
              d="M78,42 Q50,35 15,40"
              fill="none"
              stroke="var(--color-primary)"
              strokeWidth="0.4"
              strokeDasharray="1,1"
              opacity="0.6"
            />
            <path
              d="M48,30 Q36,32 24,38"
              fill="none"
              stroke="var(--color-info)"
              strokeWidth="0.4"
              strokeDasharray="1,1"
              opacity="0.6"
            />
            <path
              d="M85,40 Q86,55 88,72"
              fill="none"
              stroke="var(--color-primary)"
              strokeWidth="0.4"
              strokeDasharray="1,1"
              opacity="0.6"
            />
            <path
              d="M74,55 Q72,48 58,45"
              fill="none"
              stroke="var(--color-info)"
              strokeWidth="0.4"
              strokeDasharray="1,1"
              opacity="0.6"
            />
          </svg>

          {/* Tracking Points */}
          {trackingPoints.map((point) => (
            <div
              key={point.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 group"
              style={{ left: `${point.x}%`, top: `${point.y}%` }}
            >
              <div className={`
                relative flex items-center justify-center w-6 h-6 rounded-full cursor-pointer transition-transform hover:scale-125
                ${point.type === "origin" ? "bg-primary/20" : ""}
                ${point.type === "destination" ? "bg-success/20" : ""}
                ${point.type === "transit" ? "bg-info/20" : ""}
              `}>
                <div className={`
                  absolute inset-0 rounded-full animate-ping opacity-30
                  ${point.type === "origin" ? "bg-primary" : ""}
                  ${point.type === "destination" ? "bg-success" : ""}
                  ${point.type === "transit" ? "bg-info" : ""}
                `} />
                {point.icon === "plane" ? (
                  <Plane className={`w-3 h-3 relative z-10
                    ${point.type === "origin" ? "text-primary" : ""}
                    ${point.type === "destination" ? "text-success" : ""}
                    ${point.type === "transit" ? "text-info" : ""}
                  `} />
                ) : (
                  <Ship className={`w-3 h-3 relative z-10
                    ${point.type === "origin" ? "text-primary" : ""}
                    ${point.type === "destination" ? "text-success" : ""}
                    ${point.type === "transit" ? "text-info" : ""}
                  `} />
                )}
              </div>
              
              {/* Tooltip */}
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 text-xs font-medium bg-popover text-popover-foreground rounded border border-border opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                {point.label}
              </div>
            </div>
          ))}

          {/* Grid Lines */}
          <div className="absolute inset-0 opacity-10">
            {[...Array(6)].map((_, i) => (
              <div
                key={`h-${i}`}
                className="absolute w-full border-t border-muted-foreground"
                style={{ top: `${(i + 1) * 14.28}%` }}
              />
            ))}
            {[...Array(10)].map((_, i) => (
              <div
                key={`v-${i}`}
                className="absolute h-full border-l border-muted-foreground"
                style={{ left: `${(i + 1) * 10}%` }}
              />
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
