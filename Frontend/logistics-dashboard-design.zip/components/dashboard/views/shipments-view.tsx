"use client"

import { useState } from "react"
import {
  Search,
  Filter,
  Plus,
  MoreVertical,
  Package,
  Truck,
  Plane,
  Ship,
  ArrowRight,
  Calendar,
  MapPin,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

type ShipmentStatus = "in-transit" | "delivered" | "pending" | "delayed"

interface Shipment {
  id: string
  trackingNumber: string
  origin: string
  destination: string
  status: ShipmentStatus
  carrier: string
  carrierType: "truck" | "plane" | "ship"
  weight: string
  customer: string
  eta: string
  createdAt: string
}

const allShipments: Shipment[] = [
  {
    id: "1",
    trackingNumber: "GT-2026-78432",
    origin: "Shanghai, China",
    destination: "Los Angeles, USA",
    status: "in-transit",
    carrier: "Pacific Express",
    carrierType: "ship",
    weight: "2,450 kg",
    customer: "TechCorp Industries",
    eta: "2026-01-25",
    createdAt: "2026-01-10",
  },
  {
    id: "2",
    trackingNumber: "GT-2026-91205",
    origin: "Frankfurt, Germany",
    destination: "New York, USA",
    status: "in-transit",
    carrier: "Atlantic Air",
    carrierType: "plane",
    weight: "180 kg",
    customer: "MedSupply Direct",
    eta: "2026-01-20",
    createdAt: "2026-01-18",
  },
  {
    id: "3",
    trackingNumber: "GT-2026-45678",
    origin: "Chicago, USA",
    destination: "Miami, USA",
    status: "delivered",
    carrier: "FastFreight",
    carrierType: "truck",
    weight: "850 kg",
    customer: "Global Retail Co",
    eta: "2026-01-18",
    createdAt: "2026-01-15",
  },
  {
    id: "4",
    trackingNumber: "GT-2026-33291",
    origin: "Tokyo, Japan",
    destination: "Seattle, USA",
    status: "delayed",
    carrier: "TransPacific",
    carrierType: "ship",
    weight: "5,200 kg",
    customer: "AutoParts Express",
    eta: "2026-01-28",
    createdAt: "2026-01-05",
  },
  {
    id: "5",
    trackingNumber: "GT-2026-88764",
    origin: "London, UK",
    destination: "Boston, USA",
    status: "pending",
    carrier: "EuroAir Cargo",
    carrierType: "plane",
    weight: "320 kg",
    customer: "Fashion Forward Inc",
    eta: "2026-01-22",
    createdAt: "2026-01-19",
  },
  {
    id: "6",
    trackingNumber: "GT-2026-12098",
    origin: "Mumbai, India",
    destination: "Dubai, UAE",
    status: "in-transit",
    carrier: "Indian Ocean Lines",
    carrierType: "ship",
    weight: "1,800 kg",
    customer: "Pacific Imports Ltd",
    eta: "2026-01-24",
    createdAt: "2026-01-12",
  },
  {
    id: "7",
    trackingNumber: "GT-2026-55432",
    origin: "Berlin, Germany",
    destination: "Paris, France",
    status: "delivered",
    carrier: "EuroTruck Express",
    carrierType: "truck",
    weight: "450 kg",
    customer: "TechCorp Industries",
    eta: "2026-01-17",
    createdAt: "2026-01-16",
  },
  {
    id: "8",
    trackingNumber: "GT-2026-77821",
    origin: "Sydney, Australia",
    destination: "Singapore",
    status: "in-transit",
    carrier: "AsiaPac Air",
    carrierType: "plane",
    weight: "290 kg",
    customer: "MedSupply Direct",
    eta: "2026-01-21",
    createdAt: "2026-01-19",
  },
]

const statusConfig: Record<ShipmentStatus, { label: string; color: string }> = {
  "in-transit": { label: "In Transit", color: "bg-blue-500/20 text-blue-400" },
  delivered: { label: "Delivered", color: "bg-emerald-500/20 text-emerald-400" },
  pending: { label: "Pending", color: "bg-amber-500/20 text-amber-400" },
  delayed: { label: "Delayed", color: "bg-red-500/20 text-red-400" },
}

const carrierIcons = {
  truck: Truck,
  plane: Plane,
  ship: Ship,
}

export function ShipmentsView() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<ShipmentStatus | "all">("all")
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 6

  const filteredShipments = allShipments.filter((s) => {
    const matchesSearch =
      s.trackingNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.customer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.origin.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.destination.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || s.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const totalPages = Math.ceil(filteredShipments.length / itemsPerPage)
  const paginatedShipments = filteredShipments.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )

  const stats = {
    total: allShipments.length,
    inTransit: allShipments.filter((s) => s.status === "in-transit").length,
    delivered: allShipments.filter((s) => s.status === "delivered").length,
    delayed: allShipments.filter((s) => s.status === "delayed").length,
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Shipments</h1>
          <p className="text-muted-foreground">Manage all your shipments in one place</p>
        </div>
        <Button className="gap-2">
          <Plus className="w-4 h-4" />
          New Shipment
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/20">
                <Package className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{stats.total}</p>
                <p className="text-sm text-muted-foreground">Total</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/20">
                <Truck className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{stats.inTransit}</p>
                <p className="text-sm text-muted-foreground">In Transit</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/20">
                <Package className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{stats.delivered}</p>
                <p className="text-sm text-muted-foreground">Delivered</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-red-500/20">
                <Package className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{stats.delayed}</p>
                <p className="text-sm text-muted-foreground">Delayed</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search by tracking number, customer, or location..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value)
              setCurrentPage(1)
            }}
            className="pl-9 bg-input border-border"
          />
        </div>
        <div className="flex items-center gap-2">
          {(["all", "in-transit", "delivered", "pending", "delayed"] as const).map((status) => (
            <Button
              key={status}
              variant={statusFilter === status ? "default" : "outline"}
              size="sm"
              onClick={() => {
                setStatusFilter(status)
                setCurrentPage(1)
              }}
              className={cn(statusFilter !== status && "text-muted-foreground")}
            >
              {status === "all" ? "All" : statusConfig[status].label}
            </Button>
          ))}
        </div>
      </div>

      {/* Shipments Table */}
      <Card className="bg-card border-border">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left p-4 text-sm font-medium text-muted-foreground">Tracking</th>
                  <th className="text-left p-4 text-sm font-medium text-muted-foreground">Route</th>
                  <th className="text-left p-4 text-sm font-medium text-muted-foreground">Customer</th>
                  <th className="text-left p-4 text-sm font-medium text-muted-foreground">Carrier</th>
                  <th className="text-left p-4 text-sm font-medium text-muted-foreground">Status</th>
                  <th className="text-left p-4 text-sm font-medium text-muted-foreground">ETA</th>
                  <th className="text-left p-4 text-sm font-medium text-muted-foreground"></th>
                </tr>
              </thead>
              <tbody>
                {paginatedShipments.map((shipment) => {
                  const CarrierIcon = carrierIcons[shipment.carrierType]
                  const status = statusConfig[shipment.status]
                  return (
                    <tr key={shipment.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                      <td className="p-4">
                        <p className="font-mono text-sm text-foreground">{shipment.trackingNumber}</p>
                        <p className="text-xs text-muted-foreground">{shipment.weight}</p>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2 text-sm">
                          <span className="text-muted-foreground truncate max-w-[100px]">
                            {shipment.origin.split(",")[0]}
                          </span>
                          <ArrowRight className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                          <span className="text-foreground truncate max-w-[100px]">
                            {shipment.destination.split(",")[0]}
                          </span>
                        </div>
                      </td>
                      <td className="p-4">
                        <p className="text-sm text-foreground">{shipment.customer}</p>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <CarrierIcon className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">{shipment.carrier}</span>
                        </div>
                      </td>
                      <td className="p-4">
                        <span className={cn("px-2 py-1 rounded-full text-xs font-medium", status.color)}>
                          {status.label}
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Calendar className="w-3 h-3" />
                          {new Date(shipment.eta).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                          })}
                        </div>
                      </td>
                      <td className="p-4">
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between p-4 border-t border-border">
            <p className="text-sm text-muted-foreground">
              Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
              {Math.min(currentPage * itemsPerPage, filteredShipments.length)} of {filteredShipments.length} shipments
            </p>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8 bg-transparent"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={currentPage === page ? "default" : "outline"}
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setCurrentPage(page)}
                >
                  {page}
                </Button>
              ))}
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8 bg-transparent"
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
