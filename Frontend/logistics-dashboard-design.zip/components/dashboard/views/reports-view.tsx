"use client"

import React from "react"

import { useState } from "react"
import {
  FileText,
  Download,
  Calendar,
  Clock,
  CheckCircle2,
  Loader2,
  BarChart3,
  Package,
  Truck,
  DollarSign,
  Users,
  Filter,
  Plus,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

type ReportStatus = "ready" | "generating" | "scheduled"
type ReportType = "shipments" | "fleet" | "financial" | "customer"

interface Report {
  id: string
  name: string
  description: string
  type: ReportType
  status: ReportStatus
  generatedAt?: string
  scheduledFor?: string
  fileSize?: string
}

const reports: Report[] = [
  {
    id: "R-001",
    name: "Monthly Shipment Summary",
    description: "Complete overview of all shipments for January 2026",
    type: "shipments",
    status: "ready",
    generatedAt: "2026-01-19 08:00",
    fileSize: "2.4 MB",
  },
  {
    id: "R-002",
    name: "Fleet Performance Report",
    description: "Vehicle utilization, maintenance, and fuel efficiency metrics",
    type: "fleet",
    status: "ready",
    generatedAt: "2026-01-18 14:30",
    fileSize: "1.8 MB",
  },
  {
    id: "R-003",
    name: "Q4 Financial Report",
    description: "Revenue, costs, and profit analysis for Q4 2025",
    type: "financial",
    status: "generating",
  },
  {
    id: "R-004",
    name: "Customer Activity Report",
    description: "Customer engagement, shipment volumes, and tier analysis",
    type: "customer",
    status: "ready",
    generatedAt: "2026-01-17 10:15",
    fileSize: "3.1 MB",
  },
  {
    id: "R-005",
    name: "Weekly Operations Summary",
    description: "Operational KPIs and performance metrics",
    type: "shipments",
    status: "scheduled",
    scheduledFor: "2026-01-20 06:00",
  },
  {
    id: "R-006",
    name: "Delivery Performance Analysis",
    description: "On-time delivery rates, delays, and regional performance",
    type: "shipments",
    status: "ready",
    generatedAt: "2026-01-16 09:00",
    fileSize: "1.5 MB",
  },
]

const reportTemplates = [
  { name: "Shipment Summary", icon: Package, description: "Track all shipment activities" },
  { name: "Fleet Analysis", icon: Truck, description: "Vehicle performance metrics" },
  { name: "Financial Overview", icon: DollarSign, description: "Revenue and cost analysis" },
  { name: "Customer Insights", icon: Users, description: "Customer behavior patterns" },
]

const typeConfig: Record<ReportType, { icon: React.ElementType; color: string }> = {
  shipments: { icon: Package, color: "text-emerald-400 bg-emerald-500/20" },
  fleet: { icon: Truck, color: "text-blue-400 bg-blue-500/20" },
  financial: { icon: DollarSign, color: "text-amber-400 bg-amber-500/20" },
  customer: { icon: Users, color: "text-violet-400 bg-violet-500/20" },
}

const statusConfig: Record<ReportStatus, { label: string; icon: React.ElementType; color: string }> = {
  ready: { label: "Ready", icon: CheckCircle2, color: "text-emerald-400" },
  generating: { label: "Generating", icon: Loader2, color: "text-blue-400" },
  scheduled: { label: "Scheduled", icon: Clock, color: "text-amber-400" },
}

export function ReportsView() {
  const [selectedType, setSelectedType] = useState<ReportType | "all">("all")
  const [downloadingId, setDownloadingId] = useState<string | null>(null)

  const filteredReports = reports.filter((r) => selectedType === "all" || r.type === selectedType)

  const handleDownload = async (reportId: string) => {
    setDownloadingId(reportId)
    // Simulate download
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setDownloadingId(null)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Reports</h1>
          <p className="text-muted-foreground">Generate and download business reports</p>
        </div>
        <Button className="gap-2">
          <Plus className="w-4 h-4" />
          Create Report
        </Button>
      </div>

      {/* Quick Generate */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base font-medium">Quick Generate</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {reportTemplates.map((template) => {
              const Icon = template.icon
              return (
                <button
                  key={template.name}
                  className="flex flex-col items-center gap-3 p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors text-center"
                >
                  <div className="p-3 rounded-lg bg-primary/20">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">{template.name}</p>
                    <p className="text-xs text-muted-foreground">{template.description}</p>
                  </div>
                </button>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {(["all", "shipments", "fleet", "financial", "customer"] as const).map((type) => (
          <Button
            key={type}
            variant={selectedType === type ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedType(type)}
            className={cn(selectedType !== type && "text-muted-foreground")}
          >
            {type === "all" ? "All Reports" : type.charAt(0).toUpperCase() + type.slice(1)}
          </Button>
        ))}
      </div>

      {/* Reports List */}
      <div className="space-y-4">
        {filteredReports.map((report) => {
          const type = typeConfig[report.type]
          const status = statusConfig[report.status]
          const TypeIcon = type.icon
          const StatusIcon = status.icon
          const isDownloading = downloadingId === report.id

          return (
            <Card key={report.id} className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                  {/* Icon */}
                  <div className={cn("p-3 rounded-lg w-fit", type.color.split(" ")[1])}>
                    <TypeIcon className={cn("w-6 h-6", type.color.split(" ")[0])} />
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-medium text-foreground">{report.name}</h3>
                      <span className={cn("flex items-center gap-1 text-xs", status.color)}>
                        <StatusIcon className={cn("w-3 h-3", status.label === "Generating" && "animate-spin")} />
                        {status.label}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">{report.description}</p>
                    <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                      {report.generatedAt && (
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          Generated {report.generatedAt}
                        </span>
                      )}
                      {report.scheduledFor && (
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          Scheduled for {report.scheduledFor}
                        </span>
                      )}
                      {report.fileSize && (
                        <span className="flex items-center gap-1">
                          <FileText className="w-3 h-3" />
                          {report.fileSize}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    {report.status === "ready" && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2 bg-transparent"
                        onClick={() => handleDownload(report.id)}
                        disabled={isDownloading}
                      >
                        {isDownloading ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Download className="w-4 h-4" />
                        )}
                        {isDownloading ? "Downloading..." : "Download"}
                      </Button>
                    )}
                    {report.status === "generating" && (
                      <Button variant="outline" size="sm" disabled>
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                        Generating...
                      </Button>
                    )}
                    {report.status === "scheduled" && (
                      <Button variant="outline" size="sm">
                        Edit Schedule
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
