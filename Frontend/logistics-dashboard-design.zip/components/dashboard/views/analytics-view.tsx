"use client"

import { useState } from "react"
import {
  TrendingUp,
  TrendingDown,
  Package,
  Truck,
  Clock,
  DollarSign,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { cn } from "@/lib/utils"

const shipmentData = [
  { month: "Jul", shipments: 2400, delivered: 2200, onTime: 2100 },
  { month: "Aug", shipments: 2800, delivered: 2600, onTime: 2450 },
  { month: "Sep", shipments: 3200, delivered: 3000, onTime: 2850 },
  { month: "Oct", shipments: 2900, delivered: 2750, onTime: 2600 },
  { month: "Nov", shipments: 3500, delivered: 3300, onTime: 3100 },
  { month: "Dec", shipments: 4200, delivered: 4000, onTime: 3800 },
  { month: "Jan", shipments: 3800, delivered: 3600, onTime: 3400 },
]

const revenueData = [
  { month: "Jul", revenue: 45000 },
  { month: "Aug", revenue: 52000 },
  { month: "Sep", revenue: 61000 },
  { month: "Oct", revenue: 55000 },
  { month: "Nov", revenue: 72000 },
  { month: "Dec", revenue: 89000 },
  { month: "Jan", revenue: 78000 },
]

const carrierData = [
  { name: "Road Freight", value: 45, color: "#10b981" },
  { name: "Air Cargo", value: 25, color: "#3b82f6" },
  { name: "Ocean Shipping", value: 20, color: "#8b5cf6" },
  { name: "Rail Transport", value: 10, color: "#f59e0b" },
]

const regionData = [
  { region: "North America", shipments: 12500, growth: 12.5 },
  { region: "Europe", shipments: 8900, growth: 8.2 },
  { region: "Asia Pacific", shipments: 15200, growth: 18.7 },
  { region: "Latin America", shipments: 3400, growth: -2.1 },
  { region: "Middle East", shipments: 2100, growth: 5.4 },
]

type TimeRange = "7d" | "30d" | "90d" | "12m"

export function AnalyticsView() {
  const [timeRange, setTimeRange] = useState<TimeRange>("30d")

  const stats = [
    {
      label: "Total Shipments",
      value: "42,580",
      change: "+12.5%",
      trend: "up",
      icon: Package,
    },
    {
      label: "Active Fleet",
      value: "128",
      change: "+3.2%",
      trend: "up",
      icon: Truck,
    },
    {
      label: "Avg Delivery Time",
      value: "3.2 days",
      change: "-8.4%",
      trend: "up",
      icon: Clock,
    },
    {
      label: "Revenue",
      value: "$452K",
      change: "+18.2%",
      trend: "up",
      icon: DollarSign,
    },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Analytics</h1>
          <p className="text-muted-foreground">Performance metrics and insights</p>
        </div>
        <div className="flex items-center gap-2 bg-muted rounded-lg p-1">
          {(["7d", "30d", "90d", "12m"] as TimeRange[]).map((range) => (
            <Button
              key={range}
              variant={timeRange === range ? "default" : "ghost"}
              size="sm"
              onClick={() => setTimeRange(range)}
              className={cn(timeRange !== range && "text-muted-foreground")}
            >
              {range === "7d" ? "7 Days" : range === "30d" ? "30 Days" : range === "90d" ? "90 Days" : "12 Months"}
            </Button>
          ))}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.label} className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2 rounded-lg bg-primary/20">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div
                    className={cn(
                      "flex items-center gap-1 text-sm font-medium",
                      stat.trend === "up" ? "text-emerald-400" : "text-red-400"
                    )}
                  >
                    {stat.trend === "up" ? (
                      <ArrowUpRight className="w-4 h-4" />
                    ) : (
                      <ArrowDownRight className="w-4 h-4" />
                    )}
                    {stat.change}
                  </div>
                </div>
                <p className="text-2xl font-semibold text-foreground">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Shipments Chart */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base font-medium">Shipment Volume</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={shipmentData}>
                  <defs>
                    <linearGradient id="shipmentGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="month" stroke="#666" fontSize={12} />
                  <YAxis stroke="#666" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1a1a1a",
                      border: "1px solid #333",
                      borderRadius: "8px",
                    }}
                    labelStyle={{ color: "#fff" }}
                  />
                  <Area
                    type="monotone"
                    dataKey="shipments"
                    stroke="#10b981"
                    strokeWidth={2}
                    fill="url(#shipmentGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Revenue Chart */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base font-medium">Revenue Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="month" stroke="#666" fontSize={12} />
                  <YAxis stroke="#666" fontSize={12} tickFormatter={(value) => `$${value / 1000}k`} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1a1a1a",
                      border: "1px solid #333",
                      borderRadius: "8px",
                    }}
                    labelStyle={{ color: "#fff" }}
                    formatter={(value: number) => [`$${value.toLocaleString()}`, "Revenue"]}
                  />
                  <Bar dataKey="revenue" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Carrier Distribution */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base font-medium">Carrier Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={carrierData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {carrierData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1a1a1a",
                      border: "1px solid #333",
                      borderRadius: "8px",
                    }}
                    formatter={(value: number) => [`${value}%`, ""]}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-4">
              {carrierData.map((item) => (
                <div key={item.name} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-sm text-muted-foreground">{item.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Regional Performance */}
        <Card className="bg-card border-border lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base font-medium">Regional Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {regionData.map((region) => (
                <div key={region.region} className="flex items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-foreground">{region.region}</span>
                      <span className="text-sm text-muted-foreground">
                        {region.shipments.toLocaleString()} shipments
                      </span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full"
                        style={{ width: `${(region.shipments / 15200) * 100}%` }}
                      />
                    </div>
                  </div>
                  <div
                    className={cn(
                      "flex items-center gap-1 text-sm font-medium min-w-[70px] justify-end",
                      region.growth >= 0 ? "text-emerald-400" : "text-red-400"
                    )}
                  >
                    {region.growth >= 0 ? (
                      <TrendingUp className="w-4 h-4" />
                    ) : (
                      <TrendingDown className="w-4 h-4" />
                    )}
                    {region.growth > 0 ? "+" : ""}
                    {region.growth}%
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
