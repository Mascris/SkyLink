"use client"

import { useState } from "react"
import {
  Search,
  Plus,
  MoreVertical,
  Mail,
  Phone,
  MapPin,
  Package,
  Building2,
  User,
  Star,
  Filter,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"

type CustomerTier = "platinum" | "gold" | "silver" | "bronze"

interface Customer {
  id: string
  name: string
  company: string
  email: string
  phone: string
  location: string
  tier: CustomerTier
  totalShipments: number
  activeShipments: number
  totalSpend: number
  joinDate: string
}

const customers: Customer[] = [
  {
    id: "C-001",
    name: "Robert Anderson",
    company: "TechCorp Industries",
    email: "r.anderson@techcorp.com",
    phone: "+1 (555) 123-4567",
    location: "San Francisco, CA",
    tier: "platinum",
    totalShipments: 1250,
    activeShipments: 23,
    totalSpend: 485000,
    joinDate: "2022-03-15",
  },
  {
    id: "C-002",
    name: "Sarah Mitchell",
    company: "Global Retail Co",
    email: "s.mitchell@globalretail.com",
    phone: "+1 (555) 234-5678",
    location: "New York, NY",
    tier: "gold",
    totalShipments: 890,
    activeShipments: 15,
    totalSpend: 312000,
    joinDate: "2022-06-20",
  },
  {
    id: "C-003",
    name: "Michael Chen",
    company: "Pacific Imports Ltd",
    email: "m.chen@pacificimports.com",
    phone: "+1 (555) 345-6789",
    location: "Los Angeles, CA",
    tier: "platinum",
    totalShipments: 1580,
    activeShipments: 42,
    totalSpend: 620000,
    joinDate: "2021-11-08",
  },
  {
    id: "C-004",
    name: "Emily Johnson",
    company: "MedSupply Direct",
    email: "e.johnson@medsupply.com",
    phone: "+1 (555) 456-7890",
    location: "Chicago, IL",
    tier: "gold",
    totalShipments: 720,
    activeShipments: 8,
    totalSpend: 245000,
    joinDate: "2023-01-12",
  },
  {
    id: "C-005",
    name: "David Martinez",
    company: "AutoParts Express",
    email: "d.martinez@autoparts.com",
    phone: "+1 (555) 567-8901",
    location: "Detroit, MI",
    tier: "silver",
    totalShipments: 340,
    activeShipments: 5,
    totalSpend: 98000,
    joinDate: "2023-05-22",
  },
  {
    id: "C-006",
    name: "Jessica Thompson",
    company: "Fashion Forward Inc",
    email: "j.thompson@fashionforward.com",
    phone: "+1 (555) 678-9012",
    location: "Miami, FL",
    tier: "bronze",
    totalShipments: 156,
    activeShipments: 3,
    totalSpend: 45000,
    joinDate: "2024-02-18",
  },
]

const tierConfig: Record<CustomerTier, { label: string; color: string; bgColor: string }> = {
  platinum: { label: "Platinum", color: "text-violet-400", bgColor: "bg-violet-500/20" },
  gold: { label: "Gold", color: "text-amber-400", bgColor: "bg-amber-500/20" },
  silver: { label: "Silver", color: "text-slate-300", bgColor: "bg-slate-500/20" },
  bronze: { label: "Bronze", color: "text-orange-400", bgColor: "bg-orange-500/20" },
}

export function CustomersView() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null)

  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.email.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const stats = {
    total: customers.length,
    platinum: customers.filter((c) => c.tier === "platinum").length,
    gold: customers.filter((c) => c.tier === "gold").length,
    activeShipments: customers.reduce((sum, c) => sum + c.activeShipments, 0),
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Customers</h1>
          <p className="text-muted-foreground">Manage your customer relationships</p>
        </div>
        <Button className="gap-2">
          <Plus className="w-4 h-4" />
          Add Customer
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/20">
                <User className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{stats.total}</p>
                <p className="text-sm text-muted-foreground">Total Customers</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-violet-500/20">
                <Star className="w-5 h-5 text-violet-400" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{stats.platinum}</p>
                <p className="text-sm text-muted-foreground">Platinum Tier</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/20">
                <Star className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{stats.gold}</p>
                <p className="text-sm text-muted-foreground">Gold Tier</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/20">
                <Package className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{stats.activeShipments}</p>
                <p className="text-sm text-muted-foreground">Active Shipments</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search customers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-input border-border"
          />
        </div>
        <Button variant="outline" className="gap-2 bg-transparent">
          <Filter className="w-4 h-4" />
          Filters
        </Button>
      </div>

      {/* Customer Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredCustomers.map((customer) => {
          const tier = tierConfig[customer.tier]
          return (
            <Card
              key={customer.id}
              className={cn(
                "bg-card border-border cursor-pointer transition-all hover:border-primary/50",
                selectedCustomer?.id === customer.id && "border-primary"
              )}
              onClick={() => setSelectedCustomer(customer)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-muted text-foreground">
                        {customer.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="text-base font-medium">{customer.name}</CardTitle>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Building2 className="w-3 h-3" />
                        {customer.company}
                      </div>
                    </div>
                  </div>
                  <span className={cn("px-2 py-0.5 rounded-full text-xs font-medium", tier.bgColor, tier.color)}>
                    {tier.label}
                  </span>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground truncate">{customer.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{customer.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{customer.location}</span>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 pt-3 border-t border-border">
                  <div className="text-center">
                    <p className="text-lg font-semibold text-foreground">{customer.totalShipments}</p>
                    <p className="text-xs text-muted-foreground">Total</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-semibold text-primary">{customer.activeShipments}</p>
                    <p className="text-xs text-muted-foreground">Active</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-semibold text-foreground">
                      ${(customer.totalSpend / 1000).toFixed(0)}k
                    </p>
                    <p className="text-xs text-muted-foreground">Spent</p>
                  </div>
                </div>
                <div className="flex items-center justify-between pt-2">
                  <p className="text-xs text-muted-foreground">
                    Customer since {new Date(customer.joinDate).toLocaleDateString("en-US", { month: "short", year: "numeric" })}
                  </p>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
