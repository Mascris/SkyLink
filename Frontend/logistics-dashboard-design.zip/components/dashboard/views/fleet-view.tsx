"use client"

import React from "react"

import { useState } from "react"
import {
  Truck,
  MapPin,
  Fuel,
  Gauge,
  MoreVertical,
  Search,
  Filter,
  Plus,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Wrench,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

type VehicleStatus = "active" | "idle" | "maintenance" | "offline"

interface Vehicle {
  id: string
  name: string
  type: string
  licensePlate: string
  driver: string
  status: VehicleStatus
  location: string
  fuelLevel: number
  mileage: number
  lastService: string
  nextService: string
}

const vehicles: Vehicle[] = [
  {
    id: "VH-001",
    name: "Freight Hauler 01",
    type: "Semi-Truck",
    licensePlate: "ABC-1234",
    driver: "Mike Johnson",
    status: "active",
    location: "Interstate 95, Virginia",
    fuelLevel: 72,
    mileage: 145230,
    lastService: "2025-12-15",
    nextService: "2026-03-15",
  },
  {
    id: "VH-002",
    name: "Express Van 12",
    type: "Cargo Van",
    licensePlate: "DEF-5678",
    driver: "Sarah Chen",
    status: "active",
    location: "Los Angeles Distribution Center",
    fuelLevel: 45,
    mileage: 87450,
    lastService: "2025-11-20",
    nextService: "2026-02-20",
  },
  {
    id: "VH-003",
    name: "Heavy Loader 05",
    type: "Flatbed Truck",
    licensePlate: "GHI-9012",
    driver: "Tom Williams",
    status: "idle",
    location: "Chicago Terminal",
    fuelLevel: 88,
    mileage: 201340,
    lastService: "2026-01-05",
    nextService: "2026-04-05",
  },
  {
    id: "VH-004",
    name: "City Runner 08",
    type: "Box Truck",
    licensePlate: "JKL-3456",
    driver: "Emily Davis",
    status: "maintenance",
    location: "Miami Service Center",
    fuelLevel: 30,
    mileage: 112890,
    lastService: "2026-01-18",
    nextService: "2026-01-25",
  },
  {
    id: "VH-005",
    name: "Long Haul 03",
    type: "Semi-Truck",
    licensePlate: "MNO-7890",
    driver: "Unassigned",
    status: "offline",
    location: "Seattle Depot",
    fuelLevel: 0,
    mileage: 289100,
    lastService: "2025-10-10",
    nextService: "2026-01-10",
  },
  {
    id: "VH-006",
    name: "Regional 15",
    type: "Cargo Van",
    licensePlate: "PQR-1122",
    driver: "James Wilson",
    status: "active",
    location: "Phoenix, AZ - En Route",
    fuelLevel: 61,
    mileage: 54320,
    lastService: "2025-12-01",
    nextService: "2026-03-01",
  },
]

const statusConfig: Record<VehicleStatus, { label: string; color: string; icon: React.ElementType }> = {
  active: { label: "Active", color: "bg-emerald-500/20 text-emerald-400", icon: CheckCircle2 },
  idle: { label: "Idle", color: "bg-amber-500/20 text-amber-400", icon: AlertTriangle },
  maintenance: { label: "Maintenance", color: "bg-blue-500/20 text-blue-400", icon: Wrench },
  offline: { label: "Offline", color: "bg-red-500/20 text-red-400", icon: XCircle },
}

export function FleetView() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null)

  const filteredVehicles = vehicles.filter(
    (v) =>
      v.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.licensePlate.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.driver.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const stats = {
    total: vehicles.length,
    active: vehicles.filter((v) => v.status === "active").length,
    idle: vehicles.filter((v) => v.status === "idle").length,
    maintenance: vehicles.filter((v) => v.status === "maintenance").length,
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Fleet Management</h1>
          <p className="text-muted-foreground">Monitor and manage your vehicle fleet</p>
        </div>
        <Button className="gap-2">
          <Plus className="w-4 h-4" />
          Add Vehicle
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/20">
                <Truck className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{stats.total}</p>
                <p className="text-sm text-muted-foreground">Total Vehicles</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/20">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{stats.active}</p>
                <p className="text-sm text-muted-foreground">Active</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/20">
                <AlertTriangle className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{stats.idle}</p>
                <p className="text-sm text-muted-foreground">Idle</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/20">
                <Wrench className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{stats.maintenance}</p>
                <p className="text-sm text-muted-foreground">Maintenance</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search vehicles, drivers, or plates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-input border-border"
          />
        </div>
        <Button variant="outline" className="gap-2 bg-transparent">
          <Filter className="w-4 h-4" />
          Filters
        </Button>
      </div>

      {/* Vehicle Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredVehicles.map((vehicle) => {
          const status = statusConfig[vehicle.status]
          const StatusIcon = status.icon

          return (
            <Card
              key={vehicle.id}
              className={cn(
                "bg-card border-border cursor-pointer transition-all hover:border-primary/50",
                selectedVehicle?.id === vehicle.id && "border-primary"
              )}
              onClick={() => setSelectedVehicle(vehicle)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-muted">
                      <Truck className="w-5 h-5 text-foreground" />
                    </div>
                    <div>
                      <CardTitle className="text-base font-medium">{vehicle.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">{vehicle.licensePlate}</p>
                    </div>
                  </div>
                  <div className={cn("flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium", status.color)}>
                    <StatusIcon className="w-3 h-3" />
                    {status.label}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground truncate">{vehicle.location}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-muted-foreground">Driver:</span>
                  <span className="text-foreground">{vehicle.driver}</span>
                </div>
                <div className="grid grid-cols-2 gap-4 pt-2 border-t border-border">
                  <div className="flex items-center gap-2">
                    <Fuel className="w-4 h-4 text-muted-foreground" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-muted-foreground">Fuel</span>
                        <span className="text-foreground">{vehicle.fuelLevel}%</span>
                      </div>
                      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                        <div
                          className={cn(
                            "h-full rounded-full",
                            vehicle.fuelLevel > 50 ? "bg-emerald-500" : vehicle.fuelLevel > 25 ? "bg-amber-500" : "bg-red-500"
                          )}
                          style={{ width: `${vehicle.fuelLevel}%` }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Gauge className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">Mileage</p>
                      <p className="text-sm text-foreground">{vehicle.mileage.toLocaleString()} mi</p>
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between pt-2">
                  <p className="text-xs text-muted-foreground">
                    Next service: {new Date(vehicle.nextService).toLocaleDateString()}
                  </p>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
