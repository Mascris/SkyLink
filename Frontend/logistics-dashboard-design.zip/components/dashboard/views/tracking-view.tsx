"use client"

import { useState } from "react"
import {
  Search,
  MapPin,
  Package,
  Clock,
  CheckCircle2,
  Circle,
  Truck,
  Plane,
  Ship,
  ArrowRight,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

interface TrackingEvent {
  id: string
  status: string
  location: string
  timestamp: string
  completed: boolean
}

interface TrackedShipment {
  id: string
  trackingNumber: string
  origin: string
  destination: string
  status: "in-transit" | "delivered" | "pending" | "delayed"
  carrier: string
  carrierType: "truck" | "plane" | "ship"
  eta: string
  progress: number
  events: TrackingEvent[]
}

const recentTracking: TrackedShipment[] = [
  {
    id: "1",
    trackingNumber: "GT-2026-78432",
    origin: "Shanghai, China",
    destination: "Los Angeles, USA",
    status: "in-transit",
    carrier: "Pacific Express",
    carrierType: "ship",
    eta: "2026-01-25",
    progress: 65,
    events: [
      { id: "1", status: "Departed origin port", location: "Shanghai, China", timestamp: "2026-01-10 08:00", completed: true },
      { id: "2", status: "In transit - Pacific Ocean", location: "At Sea", timestamp: "2026-01-15 14:30", completed: true },
      { id: "3", status: "Customs clearance pending", location: "Los Angeles, USA", timestamp: "2026-01-23 09:00", completed: false },
      { id: "4", status: "Final delivery", location: "Los Angeles, USA", timestamp: "2026-01-25 17:00", completed: false },
    ],
  },
  {
    id: "2",
    trackingNumber: "GT-2026-91205",
    origin: "Frankfurt, Germany",
    destination: "New York, USA",
    status: "in-transit",
    carrier: "Atlantic Air Cargo",
    carrierType: "plane",
    eta: "2026-01-20",
    progress: 80,
    events: [
      { id: "1", status: "Package picked up", location: "Frankfurt, Germany", timestamp: "2026-01-18 06:00", completed: true },
      { id: "2", status: "Departed Frankfurt Airport", location: "Frankfurt, Germany", timestamp: "2026-01-18 14:00", completed: true },
      { id: "3", status: "Arrived JFK Airport", location: "New York, USA", timestamp: "2026-01-19 02:00", completed: true },
      { id: "4", status: "Out for delivery", location: "New York, USA", timestamp: "2026-01-20 08:00", completed: false },
    ],
  },
  {
    id: "3",
    trackingNumber: "GT-2026-45678",
    origin: "Chicago, USA",
    destination: "Miami, USA",
    status: "delivered",
    carrier: "FastFreight Logistics",
    carrierType: "truck",
    eta: "2026-01-18",
    progress: 100,
    events: [
      { id: "1", status: "Shipment created", location: "Chicago, USA", timestamp: "2026-01-15 10:00", completed: true },
      { id: "2", status: "Picked up", location: "Chicago, USA", timestamp: "2026-01-15 14:00", completed: true },
      { id: "3", status: "In transit", location: "Atlanta, USA", timestamp: "2026-01-17 06:00", completed: true },
      { id: "4", status: "Delivered", location: "Miami, USA", timestamp: "2026-01-18 11:30", completed: true },
    ],
  },
]

const carrierIcons = {
  truck: Truck,
  plane: Plane,
  ship: Ship,
}

const statusColors = {
  "in-transit": "bg-blue-500/20 text-blue-400",
  delivered: "bg-emerald-500/20 text-emerald-400",
  pending: "bg-amber-500/20 text-amber-400",
  delayed: "bg-red-500/20 text-red-400",
}

export function TrackingView() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedShipment, setSelectedShipment] = useState<TrackedShipment | null>(recentTracking[0])

  const handleSearch = () => {
    const found = recentTracking.find(
      (s) =>
        s.trackingNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.id.includes(searchQuery)
    )
    if (found) {
      setSelectedShipment(found)
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold text-foreground">Shipment Tracking</h1>
        <p className="text-muted-foreground">Track your shipments in real-time</p>
      </div>

      {/* Search Bar */}
      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Enter tracking number (e.g., GT-2026-78432)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                className="pl-12 h-12 text-base bg-input border-border"
              />
            </div>
            <Button onClick={handleSearch} className="h-12 px-8">
              Track Shipment
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Tracking List */}
        <div className="lg:col-span-1 space-y-4">
          <h2 className="text-lg font-medium text-foreground">Recent Tracking</h2>
          <div className="space-y-3">
            {recentTracking.map((shipment) => {
              const CarrierIcon = carrierIcons[shipment.carrierType]
              return (
                <Card
                  key={shipment.id}
                  className={cn(
                    "bg-card border-border cursor-pointer transition-all hover:border-primary/50",
                    selectedShipment?.id === shipment.id && "border-primary"
                  )}
                  onClick={() => setSelectedShipment(shipment)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <CarrierIcon className="w-4 h-4 text-muted-foreground" />
                        <span className="font-mono text-sm text-foreground">{shipment.trackingNumber}</span>
                      </div>
                      <span className={cn("px-2 py-0.5 rounded-full text-xs font-medium", statusColors[shipment.status])}>
                        {shipment.status.replace("-", " ")}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span className="truncate">{shipment.origin.split(",")[0]}</span>
                      <ArrowRight className="w-3 h-3 flex-shrink-0" />
                      <span className="truncate">{shipment.destination.split(",")[0]}</span>
                    </div>
                    <div className="mt-3">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-muted-foreground">Progress</span>
                        <span className="text-foreground">{shipment.progress}%</span>
                      </div>
                      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-primary rounded-full transition-all"
                          style={{ width: `${shipment.progress}%` }}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>

        {/* Tracking Details */}
        <div className="lg:col-span-2">
          {selectedShipment ? (
            <Card className="bg-card border-border">
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <CardTitle className="text-xl font-mono">{selectedShipment.trackingNumber}</CardTitle>
                    <p className="text-muted-foreground mt-1">{selectedShipment.carrier}</p>
                  </div>
                  <span className={cn("px-3 py-1 rounded-full text-sm font-medium w-fit", statusColors[selectedShipment.status])}>
                    {selectedShipment.status.replace("-", " ")}
                  </span>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Route Info */}
                <div className="flex flex-col sm:flex-row sm:items-center gap-4 p-4 bg-muted/50 rounded-lg">
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground mb-1">Origin</p>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-primary" />
                      <span className="text-foreground font-medium">{selectedShipment.origin}</span>
                    </div>
                  </div>
                  <ArrowRight className="w-5 h-5 text-muted-foreground hidden sm:block" />
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground mb-1">Destination</p>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-emerald-400" />
                      <span className="text-foreground font-medium">{selectedShipment.destination}</span>
                    </div>
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground mb-1">ETA</p>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span className="text-foreground font-medium">
                        {new Date(selectedShipment.eta).toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                          year: "numeric",
                        })}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div>
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-muted-foreground">Shipment Progress</span>
                    <span className="text-foreground font-medium">{selectedShipment.progress}%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all"
                      style={{ width: `${selectedShipment.progress}%` }}
                    />
                  </div>
                </div>

                {/* Timeline */}
                <div>
                  <h3 className="text-sm font-medium text-foreground mb-4">Tracking History</h3>
                  <div className="space-y-4">
                    {selectedShipment.events.map((event, index) => (
                      <div key={event.id} className="flex gap-4">
                        <div className="flex flex-col items-center">
                          {event.completed ? (
                            <CheckCircle2 className="w-5 h-5 text-primary" />
                          ) : (
                            <Circle className="w-5 h-5 text-muted-foreground" />
                          )}
                          {index < selectedShipment.events.length - 1 && (
                            <div className={cn("w-0.5 flex-1 mt-2", event.completed ? "bg-primary" : "bg-muted")} />
                          )}
                        </div>
                        <div className="flex-1 pb-4">
                          <p className={cn("font-medium", event.completed ? "text-foreground" : "text-muted-foreground")}>
                            {event.status}
                          </p>
                          <p className="text-sm text-muted-foreground">{event.location}</p>
                          <p className="text-xs text-muted-foreground mt-1">{event.timestamp}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-card border-border h-full flex items-center justify-center">
              <CardContent className="text-center py-12">
                <Package className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Enter a tracking number to see shipment details</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
