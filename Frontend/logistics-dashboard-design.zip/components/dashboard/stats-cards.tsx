"use client"

import React from "react"
import { Package, Truck, CheckCircle, AlertTriangle, TrendingUp, TrendingDown } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"

type FilterType = "in-transit" | "delivered" | "pending" | "delayed" | null

interface StatCard {
  title: string
  value: string
  change: string
  trend: "up" | "down"
  icon: React.ElementType
  iconBg: string
  iconColor: string
  filterId: FilterType
}

const stats: StatCard[] = [
  {
    title: "Total Shipments",
    value: "1,284",
    change: "+12.5%",
    trend: "up",
    icon: Package,
    iconBg: "bg-primary/15",
    iconColor: "text-primary",
    filterId: null,
  },
  {
    title: "In Transit",
    value: "342",
    change: "+8.2%",
    trend: "up",
    icon: Truck,
    iconBg: "bg-info/15",
    iconColor: "text-info",
    filterId: "in-transit",
  },
  {
    title: "Delivered",
    value: "892",
    change: "+15.3%",
    trend: "up",
    icon: CheckCircle,
    iconBg: "bg-success/15",
    iconColor: "text-success",
    filterId: "delivered",
  },
  {
    title: "Delayed",
    value: "24",
    change: "-4.1%",
    trend: "down",
    icon: AlertTriangle,
    iconBg: "bg-warning/15",
    iconColor: "text-warning",
    filterId: "delayed",
  },
]

interface StatsCardsProps {
  onFilterClick: (filter: FilterType) => void
  activeFilter: FilterType
}

export function StatsCards({ onFilterClick, activeFilter }: StatsCardsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat) => {
        const Icon = stat.icon
        const TrendIcon = stat.trend === "up" ? TrendingUp : TrendingDown
        const isActive = activeFilter === stat.filterId

        return (
          <Card 
            key={stat.title} 
            className={cn(
              "group cursor-pointer transition-all",
              isActive 
                ? "border-primary/50 bg-primary/5" 
                : "hover:border-primary/30"
            )}
            onClick={() => onFilterClick(stat.filterId === activeFilter ? null : stat.filterId)}
          >
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div className={`flex items-center justify-center w-11 h-11 rounded-lg ${stat.iconBg}`}>
                  <Icon className={`w-5 h-5 ${stat.iconColor}`} />
                </div>
                <div className={`flex items-center gap-1 text-xs font-medium ${
                  stat.trend === "up" ? "text-success" : "text-destructive"
                }`}>
                  <TrendIcon className="w-3 h-3" />
                  {stat.change}
                </div>
              </div>
              <div className="mt-4">
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                <p className="text-sm text-muted-foreground mt-1">{stat.title}</p>
              </div>
              {isActive && (
                <div className="mt-3 pt-3 border-t border-border">
                  <p className="text-xs text-primary">Click to clear filter</p>
                </div>
              )}
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
