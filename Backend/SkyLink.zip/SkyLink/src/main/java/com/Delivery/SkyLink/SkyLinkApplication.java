package com.Delivery.SkyLink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkyLinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkyLinkApplication.class, args);
	}

}
