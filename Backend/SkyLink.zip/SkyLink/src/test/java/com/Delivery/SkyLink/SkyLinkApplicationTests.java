package com.Delivery.SkyLink;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkyLinkApplicationTests {

	@Test
	void contextLoads() {
	}

}
